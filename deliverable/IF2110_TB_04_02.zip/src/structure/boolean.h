// 13519214
#ifndef BOOLEAN_H
#define boolean char
#define true 1
#define false 0
#endif
